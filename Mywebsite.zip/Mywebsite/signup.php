 <?php
session_start();
$con=mysqli_connect('localhost','root','','ecommerce') or die(mysqli_errorno($con));

   
            if(isset($_POST['sendotp'])){
            require('Textlocal.class.php');
           
            $Textlocal = new Textlocal(false, false,'d9H1tBPJLOo-R19eDIRiOeqvHhrkxycMX5czSXLHFH');
           
            $numbers = array($_POST['mobile']);
            $sender = 'TXTLCL';
            $otp=mt_rand(1000,9999);
            $message = 'This is your OTP'.$otp;
            try{
               $response = $Textlocal->sendSms($numbers, $message, $sender);
               setcookie('otp',$otp);
           }
            catch(Exception $e)
             {
              die($e->getmessage());
             }
          }

 if (isset($_POST['verifyotp'])) {
            $otp=$_POST['otp'];
            if ($_COOKIE['otp']==$otp) {
            $u_name=mysqli_real_escape_string($con,$_POST['u_name']);
       $u_mail=mysqli_real_escape_string($con,$_POST['mobile']);
       $u_pass=mysqli_real_escape_string($con,$_POST['u_pass']);
       $user_query="INSERT INTO `signup`(`name`, `email`, `password`) VALUES ('$u_name','$u_mail','$u_pass')";
       $user_query_res=mysqli_query($con,$user_query) or die(mysqli_error($con));
            }
        }


 ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="sign.css">

    <title>Signup</title>
  </head>
  <body>
      <div class="container">
        <div class="card cd ">
           <div class="card-header text-center">
            <div class="row">
              <div class="col-sm-12">
               <img src="logo.png" class="img-thumbnail ima" alt="OOPSI">     
              </div>
            </div>
          </div>
          <div class="card-body">
            <form method="post" action="">
         
              <div class="form-group">
                <div class="row">
                  <div class="col-sm-12">
                    <input  type="text" class="form-control" id="u_name" name="u_name" placeholder="Please Enter your Name" required>
                </div>
              </div>
            </div>
              <div class="form-group">
                <div class="row">
                  <div class="col-sm-12">
                    <input type="text" class="form-control"  name="mobile" placeholder="Please Enter your Mobile Number" max="10" min="10" required>
                </div>
              </div>
            </div>
              <div class="form-group">
                <div class="row">
                  <div class="col-sm-12">
                    <input  type="password"  class="form-control" name="u_pass" placeholder="Please Enter your Password" required><br>
                </div>
             </div>
             <div class="form-group">
                <div class="row">
                  <div class="col-sm-12">
                   <button type="submit" class="btn btn-lg btn-primary" name="sendotp">SendOTP</button><br>
                </div>
             </div>
            </div>
            <div class="form-group">
                <div class="row">
                  <div class="col-sm-12">
                    <input  type="text" class="form-control" id="otp" name="otp" placeholder="Please Enter your otp">
                </div>
              </div>
            </div>
             <div class="form-group">
                <div class="row">
                  <div class="col-sm-12">
                   <button type="submit" class="btn btn-lg btn-primary" name="verifyotp">VerifyOTP</button><br>
                </div>
             </div>
            </div>
             </div>
             
            </form>
          </div>
          
        </div>
      </div>
   </body>
   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</html>