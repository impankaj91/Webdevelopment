<?php
$con=mysqli_connect('localhost','root','','ecommerce') or die(mysqli_errorno($con));
  if(isset($_REQUEST['button']))
  {
  	$u_mail=$_REQUEST['u_mail'];
  	$u_pass=$_REQUEST['u_pass'];
  	$user_query="(select * from signup where email='$u_mail' && password='$u_pass')";
  	$user_query_res=mysqli_query($con,$user_query);
  	$row=mysqli_num_rows($user_query_res);
  	if($row==true){
  		header("Location:home.php"); 
  	}
  	else{
  		include 'wronglogin.php';
  	}
  }
 ?>