<?php
session_start();
$con=mysqli_connect('localhost','root','','ecommerce') or die(mysqli_errorno($con));

$name=$_POST['p_name'];
$price=$_POST['price'];
$qnt=$_POST['qty'];
$product=array($name,$price,$qnt);
$_SESSION[$name]=$product;
header('location:home.php')
 ?>