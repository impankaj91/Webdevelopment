<?php
session_start();
$con=mysqli_connect('localhost','root','','ecommerce') or die(mysqli_errorno($con));

   
            if(isset($_POST['sendotp'])){
            require('Textlocal.class.php');
           
            $Textlocal = new Textlocal(false, false,'d9H1tBPJLOo-R19eDIRiOeqvHhrkxycMX5czSXLHFH');
           
            $numbers = array($_POST['mobile']);
            $sender = 'TXTLCL';
            $otp=mt_rand(1000,9999);
            $message = 'This is your OTP'.$otp;
            try{
               $response = $Textlocal->sendSms($numbers, $message, $sender);
               setcookie('otp',$otp);
               header('location:verify.php');
           }
            catch(Exception $e)
             {
              die($e->getmessage());
             }
          }

 if (isset($_POST['verifyotp'])) {
            $otp=$_POST['otp'];
            if ($_COOKIE['otp']==$otp) {
            $u_name=mysqli_real_escape_string($con,$_POST['u_name']);
			 $u_mail=mysqli_real_escape_string($con,$_POST['mobile']);
			 $u_pass=mysqli_real_escape_string($con,$_POST['u_pass']);
			 $user_query="INSERT INTO `signup`(`name`, `email`, `password`) VALUES ('$u_name','$u_mail','$u_pass')";
			 $user_query_res=mysqli_query($con,$user_query) or die(mysqli_error($con));
            }
        }
 ?>